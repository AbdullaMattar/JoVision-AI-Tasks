# Tires > 2026-02-27 5:10pm
https://universe.roboflow.com/abdullam3s-workspace/tires-prqvn

Provided by a Roboflow user
License: CC BY 4.0

